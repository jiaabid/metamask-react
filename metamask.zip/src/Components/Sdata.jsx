const Sdata = [
       {
              id: 1,
              // imgsrc:"./images/melaniabilustracion-No-Planet-B-square.jpg",
              imgsrc: "./images/1.png",
              title: "A Netflix Series",
              sname: "DARK",
              link: "",
              date: "18 May 2023",
              price: "0.194 ETH"
       }, {
              id: 2,
              //   imgsrc:"https://cdnb.artstation.com/p/assets/images/images/028/663/215/large/mateus-caetano-propaganda-final-english.jpg?1595144092",
              //      imgsrc:"./images/San-Jose-Feature.jpg",
              imgsrc: "./images/2.png",
              title: "Amazon",
              sname: "THE BLIND",
              link: "",
              date: "18 May 2023",
              price: "0.194 ETH"

       }, {
              id: 3,
              // imgsrc:"https://sportshub.cbsistatic.com/i/2021/09/26/7ed6165b-be9c-4f65-b8df-e3ccf4066f11/the-sandman-dream.jpg?auto=webp&width=1080&height=1350&crop=0.8:1,smart",
              // imgsrc: "./images/image2.jpg",
              imgsrc: "./images/7.png",
              title: "A Netflix Series",
              sname: "SANDMAN",
              link: "",
              date: "18 May 2023",
              price: "0.194 ETH"
       },
       {
              id: 4,
              // imgsrc: "./images/image3.png",
              imgsrc: "./images/3.png",
              //   imgsrc:"https://wallpaperaccess.com/full/1605487.jpg",
              title: "A Netflix Series",
              sname: "DARK",
              link: "",
              date: "18 May 2023",
              price: "0.194 ETH"
       }, {
              id: 5,
              imgsrc: "./images/4.png",
              // imgsrc: "./images/2744110.jpg",
              //  imgsrc:"https://cdnb.artstation.com/p/assets/images/images/028/663/215/large/mateus-caetano-propaganda-final-english.jpg?1595144092",
              title: "Amazon",
              sname: "THE BLIND",
              link: "",
              date: "18 May 2023",
              price: "0.194 ETH"

       }, {
              id: 6,
              imgsrc: "./images/5.png",
              // imgsrc: "./images/image5.jpg",
              //  imgsrc:"https://sportshub.cbsistatic.com/i/2021/09/26/7ed6165b-be9c-4f65-b8df-e3ccf4066f11/the-sandman-dream.jpg?auto=webp&width=1080&height=1350&crop=0.8:1,smart",
              title: "A Netflix Series",
              sname: "SANDMAN",
              link: "",
              date: "18 May 2023",
              price: "0.194 ETH"
       }



]

export default Sdata;