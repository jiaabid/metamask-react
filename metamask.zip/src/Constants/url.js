export default  {
    goerliApi: "https://eth-goerli.g.alchemy.com/v2/ICiWw-r0GRzkPbmXok_3k1m43NW6_wAd",
    polygonApi: "https://polygon-mainnet.g.alchemy.com/v2/ICiWw-r0GRzkPbmXok_3k1m43NW6_wAd",
    mainnetApi: "https://eth-mainnet.g.alchemy.com/v2/ICiWw-r0GRzkPbmXok_3k1m43NW6_wAd",
    arbitrumApi: "https://arb-mainnet.g.alchemy.com/v2/ICiWw-r0GRzkPbmXok_3k1m43NW6_wAd",
}

