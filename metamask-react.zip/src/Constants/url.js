export default  {
    goerliApi: "https://eth-goerli.g.alchemy.com/v2/gusiOT-sgvvVyBQlqcU99VqcVHQ1wavP",
    polygonApi: "https://polygon-mainnet.g.alchemy.com/v2/gusiOT-sgvvVyBQlqcU99VqcVHQ1wavP",
    mainnetApi: "https://eth-mainnet.g.alchemy.com/v2/gusiOT-sgvvVyBQlqcU99VqcVHQ1wavP",
    arbitrumApi: "https://arb-mainnet.g.alchemy.com/v2/gusiOT-sgvvVyBQlqcU99VqcVHQ1wavP",
}

