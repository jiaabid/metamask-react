export default {
    erc20: "0x340eb6efFe4AaaE776C9e116a0d83e055F207e53"
}